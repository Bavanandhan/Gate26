
export const MOTIVATIONAL_QUOTES = [
  "The secret of getting ahead is getting started. - Mark Twain",
  "The only way to do great work is to love what you do. - Steve Jobs",
  "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
  "Believe you can and you're halfway there. - Theodore Roosevelt",
  "Strive for progress, not perfection.",
  "Your only limit is your mind.",
  "Precision in thought is the precursor to precision in engineering.",
  "Every problem is a force-moment problem waiting to be solved.",
  "Entropy may always increase, but so can your knowledge.",
];
